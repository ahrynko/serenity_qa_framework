package dto;

import lombok.Data;

@Data
public class User {
    private String name;
    private String phone;
    private int age;

}
